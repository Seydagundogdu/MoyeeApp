
----RAPOR 1----

SELECT registryID, ad, soyad, kimlikNo, iletisimID, CalismaDurumu.calismaDurumu, PersonelGrubu.personelGrubu, Departmanlar.departman, Pozisyonlar.pozisyon, Unvanlar.unvan, bagliOlduguMudur, bagliOlduguDirektor, bagliOlduguCeo, iseGirisTarihi, dogumTarihi, cinsiyet, maas 
FROM Personeller 
left join Pozisyonlar 
on Pozisyonlar.pozisyonID=Personeller.pozisyonID 
left join Departmanlar 
on Departmanlar.departmanID=Personeller.departmanID 
left join Unvanlar 
on Unvanlar.unvanID=Personeller.unvanID 
left join CalismaDurumu 
on CalismaDurumu.calismaDurumuID=Personeller.calismaDurumuID 
left join PersonelGrubu 
on PersonelGrubu.personelGrubuID=Personeller.personelGrubuID

----RAPOR 2----

SELECT ad,soyad,Pozisyonlar.pozisyon,iseGirisTarihi,dogumTarihi,cinsiyet,maas 
FROM Personeller 
full join Pozisyonlar 
on Pozisyonlar.pozisyonID=Personeller.pozisyonID 
WHERE maas>=4000

----RAPOR 3----

SELECT ad, soyad, Musteriler.musteri, Departmanlar.departman, Pozisyonlar.pozisyon, Unvanlar.unvan, dogumTarihi, cinsiyet
FROM Operasyon
left join 
Personeller
on Operasyon.registryID=Personeller.registryID
left join
Departmanlar
on Departmanlar.departmanID=Personeller.departmanID
left join 
Pozisyonlar
on Pozisyonlar.pozisyonID=Personeller.pozisyonID
left join 
Unvanlar
on Unvanlar.unvanID=Personeller.unvanID
full join
Musteriler
on Musteriler.musteriID=Operasyon.musteriID
order by dogumTarihi desc

----RAPOR 4----

SELECT ad, soyad, Musteriler.musteri, Vardiyalar.baslangicSaati, Vardiyalar.bitisSaati, dogumTarihi
FROM Operasyon
left join 
Personeller
on Operasyon.registryID=Personeller.registryID
full join
Musteriler
on Musteriler.musteriID=Operasyon.musteriID
inner join Vardiyalar
on Vardiyalar.musteriID=Musteriler.musteriID
WHERE unvanID=9
